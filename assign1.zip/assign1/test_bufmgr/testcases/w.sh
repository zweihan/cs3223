\rm t.txt
grep -v "write_unpin_block" testcase1.c > t.txt
